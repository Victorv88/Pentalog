package com.example.android.quadracrypto;

public class Mesaj {
    public String text,mail;
    public Mesaj( String text,String mail)
    {
        this.text=text;
        this.mail=mail;
    }
}
