package com.example.android.quadracrypto;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseUser;

public class Register extends AppCompatActivity implements View.OnClickListener {

    EditText mailIntrodus;
    EditText parola;
    EditText parolaVerificata;
    Button SignUp;
    String mail, parolaintrodusa, parolaverificata;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        mailIntrodus = findViewById(R.id.email_Introdus);
        parola = findViewById(R.id.Parola1);
        parolaVerificata = findViewById(R.id.Parola2);
        SignUp = findViewById(R.id.btn);
        mAuth = FirebaseAuth.getInstance();

        SignUp.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        mail=mailIntrodus.getText().toString();
        parolaintrodusa=parola.getText().toString();
        parolaverificata=parolaVerificata.getText().toString();
        if (parolaintrodusa.equals(parolaverificata))
        {
            if (parolaintrodusa.equals(""))
            {
                parola.setError("Enter a non-empty password");
                parola.requestFocus();
                parola.setText("");
            }
            else
            {
                mAuth.createUserWithEmailAndPassword(mail, parolaintrodusa)
                        .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    Intent intent=new Intent(Register.this, Login.class);
                                    startActivity(intent);
                                    overridePendingTransition(0, 0);
                                } else {
                                    // If sign in fails, display a message to the user.

                                        String errorCode=((FirebaseAuthException)task.getException()).getErrorCode();
                                        switch(errorCode){
                                            case "ERROR_INVALID_CUSTOM_TOKEN":
                                                Toast.makeText(Register.this, "The custom token format is incorrect. Please check the documentation.", Toast.LENGTH_LONG).show();
                                                break;
                                            case "ERROR_INVALID_EMAIL":
                                                Toast.makeText(Register.this, "The email address is badly formatted.", Toast.LENGTH_LONG).show();
                                                mailIntrodus.setError("The email address is badly formatted.");
                                                mailIntrodus.requestFocus();
                                                break;

                                            case "ERROR_WRONG_PASSWORD":
                                                Toast.makeText(Register.this, "The password is invalid or the user does not have a password.", Toast.LENGTH_LONG).show();
                                                parola.setError("password is incorrect ");
                                                parola.requestFocus();
                                                parola.setText("");
                                                break;

                                            case "ERROR_USER_MISMATCH":
                                                Toast.makeText(Register.this, "The supplied credentials do not correspond to the previously signed in user.", Toast.LENGTH_LONG).show();
                                                break;

                                            case "ERROR_REQUIRES_RECENT_LOGIN":
                                                Toast.makeText(Register.this, "This operation is sensitive and requires recent authentication. Log in again before retrying this request.", Toast.LENGTH_LONG).show();
                                                break;

                                            case "ERROR_ACCOUNT_EXISTS_WITH_DIFFERENT_CREDENTIAL":
                                                Toast.makeText(Register.this, "An account already exists with the same email address but different sign-in credentials. Sign in using a provider associated with this email address.", Toast.LENGTH_LONG).show();
                                                break;

                                            case "ERROR_EMAIL_ALREADY_IN_USE":
                                                Toast.makeText(Register.this, "The email address is already in use by another account.   ", Toast.LENGTH_LONG).show();
                                                mailIntrodus.setError("The email address is already in use by another account.");
                                                mailIntrodus.requestFocus();
                                                break;

                                            case "ERROR_CREDENTIAL_ALREADY_IN_USE":
                                                Toast.makeText(Register.this, "This credential is already associated with a different user account.", Toast.LENGTH_LONG).show();
                                                break;

                                            case "ERROR_USER_DISABLED":
                                                Toast.makeText(Register.this, "The user account has been disabled by an administrator.", Toast.LENGTH_LONG).show();
                                                break;

                                            case "ERROR_USER_TOKEN_EXPIRED":
                                                Toast.makeText(Register.this, "The user\\'s credential is no longer valid. The user must sign in again.", Toast.LENGTH_LONG).show();
                                                break;

                                            case "ERROR_USER_NOT_FOUND":
                                                Toast.makeText(Register.this, "There is no user record corresponding to this identifier. The user may have been deleted.", Toast.LENGTH_LONG).show();
                                                break;

                                            case "ERROR_INVALID_USER_TOKEN":
                                                Toast.makeText(Register.this, "The user\\'s credential is no longer valid. The user must sign in again.", Toast.LENGTH_LONG).show();
                                                break;

                                            case "ERROR_OPERATION_NOT_ALLOWED":
                                                Toast.makeText(Register.this, "This operation is not allowed. You must enable this service in the console.", Toast.LENGTH_LONG).show();
                                                break;

                                            case "ERROR_WEAK_PASSWORD":
                                                Toast.makeText(Register.this, "The given password is invalid.", Toast.LENGTH_LONG).show();
                                                parola.setError("The password is invalid it must 6 characters at least");
                                                parola.requestFocus();
                                                break;
                                        }
                                    }

                                }

                        });

            }
        }
        else{
            parolaVerificata.setError("Passwords aren't matching");
            parolaVerificata.requestFocus();
            parolaVerificata.setText("");
        }
    }
}
