package com.example.android.quadracrypto;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.auth.FirebaseAuth;

public class Register extends AppCompatActivity implements View.OnClickListener {

    EditText mailIntrodus;
    EditText parola;
    EditText parolaVerificata;
    Button SignUp;
    String mail, parolaintrodusa, parolaverificata;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        mailIntrodus = findViewById(R.id.email_Introdus);
        parola = findViewById(R.id.Parola1);
        parolaVerificata = findViewById(R.id.Parola2);
        SignUp = findViewById(R.id.btn);
        mAuth = FirebaseAuth.getInstance();

        SignUp.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        mail=mailIntrodus.getText().toString();
        parolaintrodusa=parola.getText().toString();
        parolaverificata=parolaVerificata.getText().toString();
        if (parolaintrodusa.equals(parolaverificata))
        {
            if (parolaintrodusa.equals(""))
            {
                parola.setError("Enter a non-empty password");
                parola.requestFocus();
                parola.setText("");
            }
        }
        else{
            parolaVerificata.setError("Passwords aren't matching");
            parolaVerificata.requestFocus();
            parolaVerificata.setText("");
        }
    }
}
