package com.example.android.quadracrypto;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Login extends AppCompatActivity implements View.OnClickListener{

    EditText mail_introdus;
    EditText parola_introdusa;
    TextView register_btn;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        mail_introdus=findViewById(R.id.mail_introdus);
        parola_introdusa=findViewById(R.id.parola_introdusa);
        register_btn=findViewById(R.id.register_btn);
        btn=findViewById(R.id.btn);
        btn.setOnClickListener(this);
        register_btn.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch(view.getId())
        {
            case R.id.btn:



                break;

            case R.id.register_btn:

                Intent intent=new Intent(Login.this,Register.class);
                startActivity(intent);

                break;

        }
    }
}
