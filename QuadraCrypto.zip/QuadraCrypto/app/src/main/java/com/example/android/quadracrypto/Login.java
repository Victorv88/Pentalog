package com.example.android.quadracrypto;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseUser;

public class Login extends AppCompatActivity implements View.OnClickListener{

    EditText mail_introdus;
    EditText parola_introdusa;
    TextView register_btn;
    Button btn;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        mail_introdus=findViewById(R.id.mail_introdus);
        parola_introdusa=findViewById(R.id.parola_introdusa);
        register_btn=findViewById(R.id.register_btn);
        btn=findViewById(R.id.btn);
        btn.setOnClickListener(this);
        register_btn.setOnClickListener(this);
        mAuth = FirebaseAuth.getInstance();
    }

    @Override
    public void onClick(View view) {
        switch(view.getId())
        {
            case R.id.btn:

                String mail, parola;
                mail = mail_introdus.getText().toString();
                parola = parola_introdusa.getText().toString();

                mAuth.signInWithEmailAndPassword(mail,parola).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {

                            FirebaseUser user=mAuth.getCurrentUser();
                            Intent intent = new Intent (Login.this, Question.class);
                            startActivity(intent);
                        } else {
                            String errorCode = ((FirebaseAuthException) task.getException()).getErrorCode();
                            switch (errorCode) {
                                case "ERROR_INVALID_CUSTOM_TOKEN":
                                    Toast.makeText(Login.this, "The custom token format is incorrect. Please check the documentation.", Toast.LENGTH_LONG).show();
                                    break;
                                case "ERROR_INVALID_EMAIL":
                                    Toast.makeText(Login.this, "The email address is badly formatted.", Toast.LENGTH_LONG).show();
                                    mail_introdus.setError("The email address is badly formatted.");
                                    mail_introdus.requestFocus();
                                    break;

                                case "ERROR_WRONG_PASSWORD":
                                    Toast.makeText(Login.this, "The password is invalid or the user does not have a password.", Toast.LENGTH_LONG).show();
                                    parola_introdusa.setError("password is incorrect ");
                                    parola_introdusa.requestFocus();
                                    parola_introdusa.setText("");
                                    break;

                                case "ERROR_USER_MISMATCH":
                                    Toast.makeText(Login.this, "The supplied credentials do not correspond to the previously signed in user.", Toast.LENGTH_LONG).show();
                                    break;

                                case "ERROR_REQUIRES_RECENT_LOGIN":
                                    Toast.makeText(Login.this, "This operation is sensitive and requires recent authentication. Log in again before retrying this request.", Toast.LENGTH_LONG).show();
                                    break;

                                case "ERROR_ACCOUNT_EXISTS_WITH_DIFFERENT_CREDENTIAL":
                                    Toast.makeText(Login.this, "An account already exists with the same email address but different sign-in credentials. Sign in using a provider associated with this email address.", Toast.LENGTH_LONG).show();
                                    break;

                                case "ERROR_EMAIL_ALREADY_IN_USE":
                                    Toast.makeText(Login.this, "The email address is already in use by another account.   ", Toast.LENGTH_LONG).show();
                                    mail_introdus.setError("The email address is already in use by another account.");
                                    mail_introdus.requestFocus();
                                    break;

                                case "ERROR_CREDENTIAL_ALREADY_IN_USE":
                                    Toast.makeText(Login.this, "This credential is already associated with a different user account.", Toast.LENGTH_LONG).show();
                                    break;

                                case "ERROR_USER_DISABLED":
                                    Toast.makeText(Login.this, "The user account has been disabled by an administrator.", Toast.LENGTH_LONG).show();
                                    break;

                                case "ERROR_USER_TOKEN_EXPIRED":
                                    Toast.makeText(Login.this, "The user\\'s credential is no longer valid. The user must sign in again.", Toast.LENGTH_LONG).show();
                                    break;

                                case "ERROR_USER_NOT_FOUND":
                                    Toast.makeText(Login.this, "There is no user record corresponding to this identifier. The user may have been deleted.", Toast.LENGTH_LONG).show();
                                    break;

                                case "ERROR_INVALID_USER_TOKEN":
                                    Toast.makeText(Login.this, "The user\\'s credential is no longer valid. The user must sign in again.", Toast.LENGTH_LONG).show();
                                    break;

                                case "ERROR_OPERATION_NOT_ALLOWED":
                                    Toast.makeText(Login.this, "This operation is not allowed. You must enable this service in the console.", Toast.LENGTH_LONG).show();
                                    break;

                                case "ERROR_WEAK_PASSWORD":
                                    Toast.makeText(Login.this, "The given password is invalid.", Toast.LENGTH_LONG).show();
                                    parola_introdusa.setError("The password is invalid it must 6 characters at least");
                                    parola_introdusa.requestFocus();
                                    break;
                            }
                        }
                        }
                        });
                break;

            case R.id.register_btn:

                Intent intent=new Intent(Login.this,Register.class);
                startActivity(intent);
                overridePendingTransition(0, 0);

                break;

        }
    }
}
