package com.example.android.quadracrypto;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Encrypt extends AppCompatActivity implements View.OnClickListener{

    TextView cheie;
    EditText text_introdus;
    private DatabaseReference mDatabase;
    String mail_utilizator;
    String key;
    String mesajCryptat;
    Button btn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_encrypt);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        cheie=findViewById(R.id.cheie);
        cheie.setEnabled(false);
        btn=findViewById(R.id.btn);
        btn.setOnClickListener(this);
        mDatabase = FirebaseDatabase.getInstance().getReference();
        mail_utilizator=getIntent().getStringExtra("EMAIL");
        key="abacdas";
        mesajCryptat="dasfnfdak@Sdl";
        Log.d("ABC",mail_utilizator);
    }

    @Override
    public void onClick(View view) {
        Adaugare_mesaj(key,mesajCryptat,mail_utilizator);
    }

    private void Adaugare_mesaj(String key, String mesaj_cryptat,String mail)
    {
        Mesaj date=new Mesaj(mesaj_cryptat,mail);
        Log.d("ABC",date.mail);
        Log.d("ABC",date.text);
        mDatabase.child("Text").child(key).setValue(date);
    }

}
