package com.example.android.quadracrypto;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.util.UUID;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Encrypt extends AppCompatActivity implements View.OnClickListener{

    TextView cheie;
    EditText text_introdus;
    TextView mesajCriptat;
    String key;
    private DatabaseReference mDatabase;
    String ran;
    Button btn;
    String mail_utilizator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_encrypt);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        text_introdus = findViewById(R.id.MesajIntrodus);
        cheie = findViewById(R.id.Cheie);
        btn = findViewById(R.id.btn);
        btn.setOnClickListener(this);
        mesajCriptat = findViewById(R.id.MesajCriptat);
        mDatabase = FirebaseDatabase.getInstance().getReference();
        mail_utilizator=getIntent().getStringExtra("EMAIL");

    }

    @Override
    public void onClick(View view) {

            key = cheie.getText().toString();
            ran = UUID.randomUUID().toString();
            String aux = ran.substring(0,7);
            key += aux;


            cheie.setText(key);
            btn.setEnabled(false);

            String MesajIntrodus = text_introdus.getText().toString();

            Adaugare_mesaj(aux, MesajIntrodus, mail_utilizator);
    }

    private void Adaugare_mesaj(String key, String mesaj_cryptat,String mail)
    {
        Mesaj date=new Mesaj(mesaj_cryptat,mail);
        Log.d("ABC",date.mail);
        Log.d("ABC",date.text);
        mDatabase.child("Text").child(key).setValue(date);
    }
}
