package com.example.android.quadracrypto;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Question extends AppCompatActivity implements View.OnClickListener{

    Button encrypt;
    Button decrypt;
    String mail_utilizator;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);

        encrypt = findViewById(R.id.Encrypt);
        decrypt = findViewById(R.id.Decrypt);

        encrypt.setOnClickListener(this);
        decrypt.setOnClickListener(this);
        mail_utilizator=getIntent().getStringExtra("EMAIL");
    }

   @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.Encrypt:

                Intent intent = new Intent(Question.this, Encrypt.class);
                intent.putExtra("EMAIL",mail_utilizator);
                startActivity(intent);
                overridePendingTransition(0, 0);


                break;
            case R.id.Decrypt:
                Intent intent2 = new Intent(Question.this, Decrypt.class);

                startActivity(intent2);
                overridePendingTransition(0, 0);

                break;
        }
    }
}
